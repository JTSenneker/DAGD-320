const Server = require('./Server.js').Server;

new Server();